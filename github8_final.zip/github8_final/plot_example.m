% read data
clear
set(0, 'DefaultAxesFontWeight', 'normal', ...
    'DefaultAxesFontSize', 14, ...
    'DefaultAxesFontAngle', 'normal', ... % Not sure the difference here
    'DefaultAxesFontWeight', 'normal', ... % Not sure the difference here
    'DefaultAxesTitleFontWeight', 'normal', ...
    'DefaultAxesTitleFontSizeMultiplier', 1) ;
set(0, 'DefaultLineLineWidth', 2);
set(0, 'DefaultAxesLineWidth', 2)
set(0, 'DefaultLineMarkerSize', 6)

[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');
load('data806.mat');
load('data516.mat');
load('data305.mat');
load('data1265.mat');

figure;
set(gcf,'unit','centimeters','position',[10,10,18,15]);

hold on

xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;


site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'ko','linewidth',1.5);

site_Number=516;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'ks','linewidth',1.5);

site_Number=1265;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'k^','linewidth',1.5);

site_Number=305;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'kd','linewidth',1.5);

set(gca,'ColorOrderIndex',1)


site_Number=806;
load fit_sr_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_806*1000,depth,'k-','linewidth',2);



site_Number=516;
load fit_sr_516.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_516*1000,depth,'k--','linewidth',2);



site_Number=1265;
load fit_sr_1265.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1265*1000,depth,'k-.','linewidth',2);



site_Number=305;
load fit_sr_305.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_305*1000,depth,'k:','linewidth',2);

ylim([0 800]);
xlim([0 1500]);
legend('Site 806','516','1265','305','Model 806','516','1265','305','location','southwest');

text(1150,350,'7.2 Myr old\newlineR_d=0.029 Myr^{-1}','fontweight','normal','fontsize',12)
text(680,350,'28 Myr\newlineR_d=0.0032','fontweight','normal','fontsize',12)
text(300,350,'54 Myr\newlineR_d=0.0013','fontweight','normal','fontsize',12)
text(20,350,'84 Myr\newlineR_d=0.0002','fontweight','normal','fontsize',12)
% text(1100,300,'7.24 Myr old','fontweight','bold','fontsize',14)
% text(650,300,'27.69 Myr','fontweight','bold','fontsize',14)
% text(300,300,'53.14 Myr','fontweight','bold','fontsize',14)
% text(20,300,'84.35 Myr','fontweight','bold','fontsize',14)
text(850,40,'Rate decreases with age','fontweight','normal','fontsize',14)
annotation( 'arrow', 'X', [0.85 0.6], 'Y', [0.85 0.85])

print('example_sr.jpg','-djpeg','-r1200');


% 
% figure
% hold on
% 
% plot(Rd806,z806,'-','linewidth',2);
% plot(Rd516,z516,'-','linewidth',2);
% plot(Rd1265,z1265,'-','linewidth',2);
% plot(Rd305,z305,'-','linewidth',2);
% 
% set(gca,'Ydir','reverse')
% set(gca,'xscale','log');
% 
% xlabel('R_b (Myr^{-1})');
% ylabel('Depth (m)')
% legend('Site 806','516','1265','305','location','southwest');
% box on
% ax = gca;
% ax.LineWidth = 1.5;
% 
% ylim([0 800]);
% print('example_Rd.jpg','-djpeg','-r1200');


