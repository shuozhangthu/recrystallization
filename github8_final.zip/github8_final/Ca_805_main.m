clear all;
load('workspace_805.mat');

site_Number = 805;

%-------input data----------
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
Ca2_data=CalciumCamM(index);

[depth, a_order] = sort(depth);
Ca2_data = Ca2_data(a_order,:);

alpha0=0.00015;
beta0=600;
gamma0=600;
v0=0;
grc_ca0=0;

y0=[alpha0,beta0,gamma0,v0,grc_ca0];
lb=[0,0,0,0,0];
ub=[0,1,1000,0,1];

% lb=[-1,-1,0,0,0];
% ub=[1,1,10000,0,1];

y = lsqcurvefit(@Ca_805_function,y0,depth,Ca2_data,lb,ub)
% y=y0;

figure
plot(Ca_805_function(y,depth),depth,'linewidth',2)
set(gca,'Ydir','reverse')
title('Calcium (mM) in pore water (site:805)')
xlabel('Calcium (mM) in pore water');
ylabel('Depth (m)')
set(gca,'FontSize',12)

hold on;

scatter (Ca2_data,depth);

% 
% 
% figure
% plot(t, Ca_805_function(y,z),'linewidth',2)
% hold on
% plot(t, 10.62 + 0.161*t,'linewidth',2)
% 
% ylabel('Calcium (mM) in pore water');
% xlabel('Age (Myr)')
% set(gca,'FontSize',12)


newName = 'y805';
S.(newName) = [site_Number,y];
save('parameters_Ca_805.mat', '-struct', 'S'); 

newName = 'fit_ca_805';
S.(newName) = Ca_805_function(y,depth);
save('fit_ca_805.mat', '-struct', 'S');