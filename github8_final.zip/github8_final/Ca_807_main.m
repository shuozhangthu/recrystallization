% 1D transport using MATLAB pdepe                   
clear
set(0, 'DefaultAxesFontWeight', 'normal', ...
    'DefaultAxesFontSize', 16, ...
    'DefaultAxesFontAngle', 'normal', ... % Not sure the difference here
    'DefaultAxesFontWeight', 'normal', ... % Not sure the difference here
    'DefaultAxesTitleFontWeight', 'normal', ...
    'DefaultAxesTitleFontSizeMultiplier', 1) ;
set(0, 'DefaultLineLineWidth', 2);
set(0, 'DefaultAxesLineWidth', 2)
set(0, 'DefaultLineMarkerSize', 6)
site_Number = 807;

%-------input data----------
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

index=(Site1==site_Number);
depth2=Depthmbsf1(index);
Ca2_data=CalciumCamM(index);
Mg_data=MagnesiumMgmM(index);

figure
set(gcf,'unit','centimeters','position',[10,10,18,15]);

scatter (Mg_data,depth2,'linewidth',2);

set(gca,'Ydir','reverse')
title('(a) Site 807')
xlabel('Pore fluid [Mg] (mM)');
ylabel('Depth (m)')

box on
ax = gca;
ax.LineWidth = 1.5;

alpha0=0;
beta0=0.000001;
gamma0=100;
v0=0;
grc_ca0=0;

y0=[alpha0,beta0,gamma0,v0,grc_ca0];
lb=[0,0,0,0,0];
ub=[0,1,1000,0,1];

y = lsqcurvefit(@Ca_807_function,y0,depth2,Ca2_data,lb,ub)


figure
set(gcf,'unit','centimeters','position',[10,10,18,15]);

plot(Ca_807_function(y,depth2),depth2,'k-','linewidth',2)

hold on

% y(2)=0.9*y(2);
% plot(Ca_807_function(y,depth2),depth2,'k--','linewidth',2)
% y(2)=1.1*y(2)/0.9;
% plot(Ca_807_function(y,depth2),depth2,'k-.','linewidth',2)
% y(2)=0;
% plot(Ca_807_function(y,depth2),depth2,'k:','linewidth',2)

set(gca,'Ydir','reverse')
title('(a) Site 807')
xlabel('Pore fluid [Ca] (mM)');
ylabel('Depth (m)')

hold on;

scatter (Ca2_data,depth2,'k','linewidth',1.5);
legend('R_{net}=5.7\times10^{-5}e^{-z/725} Myr^{-1}','90%R_{net}','110%R_{net}','R_{net}=0','measured [Ca]','fontsize',12,'location','southwest')

box on
ax = gca;
ax.LineWidth = 1.5;
% print('Rnet_example_807.jpg','-djpeg','-r1200');


newName = 'y807';
S.(newName) = [site_Number,y];
save('parameters_Ca_807.mat', '-struct', 'S'); 

newName = 'fit_ca_807';
S.(newName) = Ca_807_function(y,depth2);
save('fit_ca_807.mat', '-struct', 'S');