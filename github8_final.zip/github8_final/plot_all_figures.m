
age_mean=age_mean';

load('data803.mat');
load('data805.mat');
load('data806.mat');
load('data807.mat');
load('data1263.mat');
load('data1264.mat');
load('data1265.mat');
load('data1266.mat');
load('data982.mat');
load('data1088.mat');
load('data1092.mat');
load('data1120.mat');
load('data1169.mat');
load('data1194.mat');
load('data516.mat');
load('data305.mat');
load('data289.mat');
load('data590.mat');
load('data575.mat');
load('data593.mat');
load('data1170.mat');
load('data1171.mat');
load('data1336.mat');
load('data1338.mat');
load('workspace_803.mat');
load('workspace_805.mat');
load('workspace_806.mat');
load('workspace_807.mat');
load('workspace_1263.mat');
load('workspace_1264.mat');
load('workspace_1265.mat');
load('workspace_1266.mat');
load('workspace_982.mat');
load('workspace_1088.mat');
load('workspace_1092.mat');
load('workspace_1120.mat');
load('workspace_1169.mat');
load('workspace_1194.mat');
load('workspace_516.mat');
load('workspace_305.mat');
load('workspace_289.mat');
load('workspace_590.mat');
load('workspace_575.mat');
load('workspace_593.mat');
load('workspace_1170.mat');
load('workspace_1171.mat');
load('workspace_1336.mat');
load('workspace_1338.mat');

sed_rate=[sedi_rate_803;sedi_rate_805;sedi_rate_806;sedi_rate_807;sedi_rate_982;sedi_rate_1088;sedi_rate_1092;sedi_rate_1120;sedi_rate_1194;sedi_rate_1263;sedi_rate_1264;sedi_rate_1265;sedi_rate_1266;sedi_rate_516;sedi_rate_305;sedi_rate_289;sedi_rate_590;sedi_rate_575;sedi_rate_593];

z807=z807(1:707);
Re807=Re807(1:707);
Rd807=Rd807(1:707);

t_590=1/38;
z590=transpose([0:1:500]);
Rd590=transpose(0.0027+0.067*exp(-z590/38/2.1));
Re590 = cumsum(Rd590)*t_590*100; % in percentage (%)
Re803c = cumsum(Rd803)*t_803*100; % in percentage (%)
Re805c = cumsum(Rd805)*t_805*100; % in percentage (%)
Re806c = cumsum(Rd806)*t_806*100; % in percentage (%)
Re807c = cumsum(Rd807)*t_807*100; % in percentage (%)

% f_a = 0.525;
% f_b = 0.125;
% f_c = 175;
load fp590.mat;

phi590=f_a+f_b*exp(-z590/f_c);   % porosity corresponding to the depth grid
comp_rate_590=(phi590-f_a)./(1-phi590)/f_c/t_590;

% 
% f_a = 0;
% f_b = 68.6/100;
% f_c = 1/0.00075;
load fp803.mat;

phi803=f_a+f_b*exp(-z803/f_c);   % porosity corresponding to the depth grid
comp_rate_803=(phi803-f_a)./(1-phi803)/f_c/t_803;


% f_a = 0;
% f_b = 70.2/100;
% f_c = 1/0.00076;
load fp805.mat;

phi805=f_a+f_b*exp(-z805/f_c);   % porosity corresponding to the depth grid
comp_rate_805=(phi805-f_a)./(1-phi805)/f_c/t_805;

% f_a = 0;
% f_b = 69.2/100;
% f_c = 1/0.00045;
load fp806.mat;

phi806=f_a+f_b*exp(-z806/f_c);   % porosity corresponding to the depth grid
comp_rate_806=(phi806-f_a)./(1-phi806)/f_c/t_806;

% 
% f_a = 0;
% f_b = 69.6/100;
% f_c = 1/0.00051;
load fp807.mat;

phi807=f_a+f_b*exp(-z807/f_c);   % porosity corresponding to the depth grid
comp_rate_807=(phi807-f_a)./(1-phi807)/f_c/t_807;

load fp1263.mat;

phi1263=f_a+f_b*exp(-z1263/f_c);   % porosity corresponding to the depth grid
comp_rate_1263=(phi1263-f_a)./(1-phi1263)/f_c/t_1263;

load fp1264.mat;

phi1264=f_a+f_b*exp(-z1264/f_c);   % porosity corresponding to the depth grid
comp_rate_1264=(phi1264-f_a)./(1-phi1264)/f_c/t_1264;

load fp1265.mat;

phi1265=f_a+f_b*exp(-z1265/f_c);   % porosity corresponding to the depth grid
comp_rate_1265=(phi1265-f_a)./(1-phi1265)/f_c/t_1265;

load fp1266.mat;

phi1266=f_a+f_b*exp(-z1266/f_c);   % porosity corresponding to the depth grid
comp_rate_1266=(phi1266-f_a)./(1-phi1266)/f_c/t_1266;

load fp982.mat;

phi982=f_a+f_b*exp(-z982/f_c);   % porosity corresponding to the depth grid
comp_rate_982=(phi982-f_a)./(1-phi982)/f_c/t_982;

load fp1088.mat;

phi1088=f_a+f_b*exp(-z1088/f_c);   % porosity corresponding to the depth grid
comp_rate_1088=(phi1088-f_a)./(1-phi1088)/f_c/t_1088;

load fp1092.mat;

phi1092=f_a+f_b*exp(-z1092/f_c);   % porosity corresponding to the depth grid
comp_rate_1092=(phi1092-f_a)./(1-phi1092)/f_c/t_1092;

load fp1120.mat;

phi1120=f_a+f_b*exp(-z1120/f_c);   % porosity corresponding to the depth grid
comp_rate_1120=(phi1120-f_a)./(1-phi1120)/f_c/t_1120;

load fp1169.mat;

phi1169=f_a+f_b*exp(-z1169/f_c);   % porosity corresponding to the depth grid
comp_rate_1169=(phi1169-f_a)./(1-phi1169)/f_c/t_1169;

load fp1194.mat;

phi1194=f_a+f_b*exp(-z1194/f_c);   % porosity corresponding to the depth grid
comp_rate_1194=(phi1194-f_a)./(1-phi1194)/f_c/t_1194;


Ce803 = cumsum(Rd803.*transpose(1-phi803))*t_803*100; % in percentage (%)
Ce805 = cumsum(Rd805.*transpose(1-phi805))*t_805*100; % in percentage (%)
Ce806 = cumsum(Rd806.*transpose(1-phi806))*t_806*100; % in percentage (%)
Ce807 = cumsum(Rd807.*transpose(1-phi807))*t_807*100; % in percentage (%)
Ce590 = cumsum(Rd590.*transpose(1-phi590))*t_590*100; % in percentage (%)


figure;
hold on

plot(phi803,z803,'-','linewidth',2);
plot(phi805,z805,'-.','linewidth',2);
plot(phi806,z806,':','linewidth',2);
plot(phi807,z807,'--','linewidth',2);
% plot(phi590,z590,'-','linewidth',2);

plot(phi982,z982,'-','linewidth',2);
plot(phi1088,z1088,'-.','linewidth',2);
plot(phi1092,z1092,':','linewidth',2);
plot(phi1120,z1120,'--','linewidth',2);
plot(phi1169,z1169,'-','linewidth',2);
plot(phi1194,z1194,'-.','linewidth',2);

plot(phi1263,z1263,'-','linewidth',2);
plot(phi1264,z1264,'-.','linewidth',2);
plot(phi1265,z1265,':','linewidth',2);
plot(phi1266,z1266,'--','linewidth',2);


% set(gca, 'XScale', 'log')
set(gca,'Ydir','reverse')

xlabel('Porosity');
ylabel('Present-day depth (m)')
set(gca,'FontSize',12,'FontWeight','bold')
legend('Site 803','805','806','807','982','1088','1092','1120','1169','1194','1263','1264','1265','1266','Location','SouthEast');
box on
ax = gca;
ax.LineWidth = 1.5;

% print('porosity_depth.jpg','-djpeg','-r600');



figure;
set(gcf, 'Position',  [100, 100, 1000, 900])

subplot(2,2,1)
title('(a)');
hold on


s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
rd80x=[Rd803(1),Rd805(1),Rd806(1),Rd807(1)];

scatter(s80x,rd80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
rd126x=[Rd1263(1),Rd1264(1),Rd1265(1),Rd1266(1)];

scatter(s126x,rd126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
rd98x=[Rd982(1),Rd1088(1),Rd1092(1),Rd1120(1),Rd1169(1),Rd1194(1)];

scatter(s98x,rd98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
rd28x=[Rd516(1);Rd305(1);Rd289(1);Rd590(1);Rd575(1);Rd593(1)];

scatter(s28x,rd28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];

rd117x=[Rd1170(1);Rd1171(1);Rd1336(1);Rd1338(1)];
scatter(s117x,rd117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Recrystallization rate at 0 m(Myr_{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
set(gca,'yscale','log');

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northwest');


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.0001 1])
set(gca,'xscale','log');

% print('recry_sedimentation.jpg','-djpeg','-r600');



subplot(2,2,3)
hold on
title('(c)');

age80x=age_mean(1:4);
rd80x=[Rd803(1),Rd805(1),Rd806(1),Rd807(1)];
scatter(age80x,rd80x,40,'filled','o');

age126x=age_mean(5:8);
rd126x=[Rd1263(1),Rd1264(1),Rd1265(1),Rd1266(1)];
scatter(age126x,rd126x,40,'filled','s');

age98x=age_mean(9:14);
rd98x=[Rd982(1),Rd1088(1),Rd1092(1),Rd1120(1),Rd1169(1),Rd1194(1)];
scatter(age98x,rd98x,40,'filled','d');

age28x=age_mean(15:20);
rd28x=[Rd516(1);Rd305(1);Rd289(1);Rd590(1);Rd575(1);Rd593(1)];
scatter(age28x,rd28x,40,'filled','^');

% age117x=age_mean(21:24);
% rd117x=[Rd1170(1);Rd1171(1);Rd1336(1);Rd1338(1)];
% scatter(age117x,rd117x,40,'filled','h');



xlabel('Mean age of sediments at 100 m (Myr)');
ylabel('Recrystallization rate at 0 m (Myr^{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
set(gca,'xscale','log');
set(gca,'yscale','log');

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northeast');

box on
ax = gca;
ax.LineWidth = 1.5;
% xlim([0 60])
xlim([1 100])
ylim([0.0001 1])

% figure;
% hold on
% plot(z803*t_803,Rd803);
% plot(z805*t_805,Rd805);
% plot(z806*t_806,Rd806);
% plot(z807*t_807,Rd807);
% xlabel('Sediment age (Myr)');
% ylabel('Recrystallization rate (Myr_{-1})')
% set(gca,'FontSize',12)
% set(gca,'yscale','log');
% set(gca,'xscale','log');
% 
% % h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northwest');
% 
% 
% box on
% ax = gca;
% ax.LineWidth = 1.5;
% % xlim([1 100])
% % ylim([0.0001 1])



subplot(2,2,2)
hold on
title('(b)');


s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
rd80x=[interp1(z803,Rd803,50),interp1(z805,Rd805,50),interp1(z806,Rd806,50),interp1(z807,Rd807,50)];

scatter(s80x,rd80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
rd126x=[interp1(z1263,Rd1263,50),interp1(z1264,Rd1264,50),interp1(z1265,Rd1265,50),interp1(z1266,Rd1266,50)];

scatter(s126x,rd126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
rd98x=[interp1(z982,Rd982,50),interp1(z1088,Rd1088,50),interp1(z1092,Rd1092,50),interp1(z1120,Rd1120,50),interp1(z1169,Rd1169,50),interp1(z1194,Rd1194,50)];

scatter(s98x,rd98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
rd28x=[interp1(z516,Rd516,50),interp1(z305,Rd305,50),interp1(z289,Rd289,50),interp1(z590,Rd590,50),interp1(z575,Rd575,50),interp1(z593,Rd593,50)];

scatter(s28x,rd28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];
rd117x=[interp1(z1170,Rd1170,50),interp1(z1171,Rd1171,50),interp1(z1336,Rd1336,50),interp1(z1338,Rd1338,50)];

scatter(s117x,rd117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Recrystallization rate at 50m (Myr_{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
set(gca,'yscale','log');

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northwest');


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.0001 1])
set(gca,'xscale','log');



subplot(2,2,4)
hold on
title('(d)');

age80x=age_mean(1:4);
rd80x=[interp1(z803,Rd803,50),interp1(z805,Rd805,50),interp1(z806,Rd806,50),interp1(z807,Rd807,50)];
scatter(age80x,rd80x,40,'filled','o');

age126x=age_mean(5:8);
rd126x=[interp1(z1263,Rd1263,50),interp1(z1264,Rd1264,50),interp1(z1265,Rd1265,50),interp1(z1266,Rd1266,50)];
scatter(age126x,rd126x,40,'filled','s');

age98x=age_mean(9:14);
rd98x=[interp1(z982,Rd982,50),interp1(z1088,Rd1088,50),interp1(z1092,Rd1092,50),interp1(z1120,Rd1120,50),interp1(z1169,Rd1169,50),interp1(z1194,Rd1194,50)];
scatter(age98x,rd98x,40,'filled','d');

age28x=age_mean(15:20);
rd28x=[interp1(z516,Rd516,50),interp1(z305,Rd305,50),interp1(z289,Rd289,50),interp1(z590,Rd590,50),interp1(z575,Rd575,50),interp1(z593,Rd593,50)];
scatter(age28x,rd28x,40,'filled','^');

% age117x=age_mean(21:24);
% rd117x=[interp1(z1170,Rd1170,50),interp1(z1171,Rd1171,50),interp1(z1336,Rd1336,50),interp1(z1338,Rd1338,50)];
% scatter(age117x,rd117x,40,'filled','h');



xlabel('Mean age of sediments at 100 m (Myr)');
ylabel('Recrystallization rate at 50 m (Myr^{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
set(gca,'xscale','log');
set(gca,'yscale','log');

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northeast');

box on
ax = gca;
ax.LineWidth = 1.5;
% xlim([0 60])
xlim([1 100])
ylim([0.0001 1])

% print('recry_age.jpg','-djpeg','-r600');



figure;
hold on

plot(Re803,z803,'-','linewidth',2);
plot(Re805,z805,'-.','linewidth',2);
plot(Re806,z806,':','linewidth',2);
plot(Re807,z807,'--','linewidth',2);

plot(Re982,z982,'-','linewidth',2);
plot(Re1088,z1088,'-.','linewidth',2);
plot(Re1092,z1092,':','linewidth',2);
plot(Re1120,z1120','--','linewidth',2);
plot(Re1169,z1169,'-','linewidth',2);
plot(Re1194,z1194,'-.','linewidth',2);


plot(Re1263,z1263,'-','linewidth',2);
plot(Re1264,z1264,'-.','linewidth',2);
plot(Re1265,z1265,':','linewidth',2);
plot(Re1266,z1266,'--','linewidth',2);

set(gca,'Ydir','reverse')

xlabel('Fraction of recrystallized calcite (%)');
ylabel('Present-day depth (m)')
set(gca,'FontSize',12,'FontWeight','bold')
legend('Site 803','805','806','807','982','1088','1092','1120','1169','1194','1263','1264','1265','1266','Location','northeast');
box on
ax = gca;
ax.LineWidth = 1.5;

xlim([0 100]);
% print('recrystallized.jpg','-djpeg','-r600');


figure;
hold on

plot(Re803,z803*t_803,'-','linewidth',2);
plot(Re805,z805*t_805,'-.','linewidth',2);
plot(Re806,z806*t_806,':','linewidth',2);
plot(Re807,z807*t_807,'--','linewidth',2);

plot(Re982,z982*t_982,'-','linewidth',2);
plot(Re1088,z1088*t_1088,'-.','linewidth',2);
plot(Re1092,z1092*t_1092,':','linewidth',2);
plot(Re1120,z1120*t_1120,'--','linewidth',2);
plot(Re1169,z1169*t_1169,'-','linewidth',2);
plot(Re1194,z1194*t_1194,'-.','linewidth',2);


plot(Re1263,z1263*t_1263,'-','linewidth',2);
plot(Re1264,z1264*t_1264,'-.','linewidth',2);
plot(Re1265,z1265*t_1265,':','linewidth',2);
plot(Re1266,z1266*t_1266,'--','linewidth',2);

set(gca,'Ydir','reverse')

xlabel('Fraction of recrystallized calcite (%)');
ylabel('Age of sediment (Myr)')
set(gca,'FontSize',12,'FontWeight','bold')
legend('Site 803','805','806','807','982','1088','1092','1120','1169','1194','1263','1264','1265','1266','Location','northeast');
box on
ax = gca;
ax.LineWidth = 1.5;

xlim([0 100]);
% print('recrystallized_age.jpg','-djpeg','-r600');



figure;
hold on

plot(Re803,z803,'-','linewidth',2);
plot(Re805,z805,'-.','linewidth',2);
plot(Re806,z806,':','linewidth',2);
plot(Re807,z807,'--','linewidth',2);

plot(Re982,z982,'-','linewidth',2);
plot(Re1088,z1088,'-.','linewidth',2);
plot(Re1092,z1092,':','linewidth',2);
plot(Re1120,z1120','--','linewidth',2);
plot(Re1169,z1169,'-','linewidth',2);
plot(Re1194,z1194,'-.','linewidth',2);


plot(Re1263,z1263,'-','linewidth',2);
plot(Re1264,z1264,'-.','linewidth',2);
plot(Re1265,z1265,':','linewidth',2);
plot(Re1266,z1266,'--','linewidth',2);

set(gca,'Ydir','reverse')

xlabel('Fraction of recrystallized calcite (%)');
ylabel('Present-day depth (m)')
set(gca,'FontSize',12,'FontWeight','bold')
legend('Site 803','805','806','807','982','1088','1092','1120','1169','1194','1263','1264','1265','1266','Location','southwest');
box on
ax = gca;
ax.LineWidth = 1.5;

xlim([0 100]);
set(gca,'xscale','log');

% print('recrystallized_log.jpg','-djpeg','-r600');


figure;
hold on

plot(Re803,z803*t_803,'-','linewidth',2);
plot(Re805,z805*t_805,'-.','linewidth',2);
plot(Re806,z806*t_806,':','linewidth',2);
plot(Re807,z807*t_807,'--','linewidth',2);

plot(Re982,z982*t_982,'-','linewidth',2);
plot(Re1088,z1088*t_1088,'-.','linewidth',2);
plot(Re1092,z1092*t_1092,':','linewidth',2);
plot(Re1120,z1120*t_1120,'--','linewidth',2);
plot(Re1169,z1169*t_1169,'-','linewidth',2);
plot(Re1194,z1194*t_1194,'-.','linewidth',2);


plot(Re1263,z1263*t_1263,'-','linewidth',2);
plot(Re1264,z1264*t_1264,'-.','linewidth',2);
plot(Re1265,z1265*t_1265,':','linewidth',2);
plot(Re1266,z1266*t_1266,'--','linewidth',2);

set(gca,'Ydir','reverse')

xlabel('Fraction of recrystallized calcite (%)');
ylabel('Age of sediment (Myr)')
set(gca,'FontSize',12,'FontWeight','bold')
legend('Site 803','805','806','807','982','1088','1092','1120','1169','1194','1263','1264','1265','1266','Location','southwest');
box on
ax = gca;
ax.LineWidth = 1.5;

xlim([0 100]);
set(gca,'xscale','log');

% print('recrystallized_age_log.jpg','-djpeg','-r600');


figure
hold on
s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
Re80x=[interp1(z803,Re803,50),interp1(z805,Re805,50),interp1(z806,Re806,50),interp1(z807,Re807,50)];

scatter(s80x,Re80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
Re126x=[interp1(z1263,Re1263,50),interp1(z1264,Re1264,50),interp1(z1265,Re1265,50),interp1(z1266,Re1266,50)];

scatter(s126x,Re126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
Re98x=[interp1(z982,Re982,50),interp1(z1088,Re1088,50),interp1(z1092,Re1092,50),interp1(z1120,Re1120,50),interp1(z1169,Re1169,50),interp1(z1194,Re1194,50)];

scatter(s98x,Re98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
Re28x=[interp1(z516,Re516,50),interp1(z305,Re305,50),interp1(z289,Re289,50),interp1(z590,Re590,50),interp1(z575,Re575,50),interp1(z593,Re593,50)];

scatter(s28x,Re28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];
Re117x=[interp1(z1170,Re1170,50),interp1(z1171,Re1171,50),interp1(z1336,Re1336,50),interp1(z1338,Re1338,50)];

scatter(s117x,Re117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Recrystallized fraction at 50m (%)')
set(gca,'FontSize',12,'FontWeight','bold')

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','northwest');


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.1 100])
set(gca,'xscale','log');
set(gca,'yscale','log');
% print('recrystallized50_sedimentation_rate.jpg','-djpeg','-r600');



figure
hold on
s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
Re80x=[interp1(z803,Re803,100),interp1(z805,Re805,100),interp1(z806,Re806,100),interp1(z807,Re807,100)];

scatter(s80x,Re80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
Re126x=[interp1(z1263,Re1263,100),interp1(z1264,Re1264,100),interp1(z1265,Re1265,100),interp1(z1266,Re1266,100)];

scatter(s126x,Re126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
Re98x=[interp1(z982,Re982,100),interp1(z1088,Re1088,100),interp1(z1092,Re1092,100),interp1(z1120,Re1120,100),interp1(z1169,Re1169,100),interp1(z1194,Re1194,100)];

scatter(s98x,Re98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
Re28x=[interp1(z516,Re516,100),interp1(z305,Re305,100),interp1(z289,Re289,100),interp1(z590,Re590,100),interp1(z575,Re575,100),interp1(z593,Re593,100)];

scatter(s28x,Re28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];
Re117x=[interp1(z1170,Re1170,100),interp1(z1171,Re1171,100),interp1(z1336,Re1336,100),interp1(z1338,Re1338,100)];

scatter(s117x,Re117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Recrystallized fraction at 100m (%)')
set(gca,'FontSize',12,'FontWeight','bold')

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','Location','southeast');


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.1 100])
% set(gca,'xscale','log');
% set(gca,'yscale','log');
% print('recrystallized100_sedimentation_rate.jpg','-djpeg','-r600');



figure
set(gcf, 'Position',  [100, 100, 1000, 400])

subplot(1,2,2)
title('(b)')
hold on
s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
Re80x=[interp1(z803,Re803,150),interp1(z805,Re805,150),interp1(z806,Re806,150),interp1(z807,Re807,150)];

scatter(s80x,Re80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
Re126x=[interp1(z1263,Re1263,150),interp1(z1264,Re1264,150),interp1(z1265,Re1265,150),interp1(z1266,Re1266,150)];

scatter(s126x,Re126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
Re98x=[interp1(z982,Re982,150),interp1(z1088,Re1088,150),interp1(z1092,Re1092,150),interp1(z1120,Re1120,150),interp1(z1169,Re1169,150),interp1(z1194,Re1194,150)];

scatter(s98x,Re98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
Re28x=[interp1(z516,Re516,150),interp1(z305,Re305,150),interp1(z289,Re289,150),interp1(z590,Re590,150),interp1(z575,Re575,150),interp1(z593,Re593,150)];

scatter(s28x,Re28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];
Re117x=[interp1(z1170,Re1170,150),interp1(z1171,Re1171,150),interp1(z1336,Re1336,150),interp1(z1338,Re1338,150)];

scatter(s117x,Re117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Recrystallized fraction at 150m (%)')
set(gca,'FontSize',12,'FontWeight','bold')

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171\newlineU1336,U1338','Location','southeast','FontSize',10);


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.1 100])
set(gca,'xscale','log');
set(gca,'yscale','log');
% print('recrystallized150_sedimentation_rate.jpg','-djpeg','-r600');

subplot(1,2,1)
title('(a)')

write_table;

zz(:,7)=zz(:,3).*zz(:,4).*(1-exp(-150./zz(:,4)))/150;

% figure;
hold on

s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
rd80x=zz(1:4,7);

scatter(s80x,rd80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
rd126x=zz(11:14,7);

scatter(s126x,rd126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
rd98x=zz(5:10,7);

scatter(s98x,rd98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
rd28x=zz(15:20,7);

scatter(s28x,rd28x,40,'filled','^');

% s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];
% rd117x=zz(21:24,7);
% 
% scatter(s117x,rd117x,40,'filled','h');

xlabel('Sedimentation rate (m/Myr)');
ylabel('Average recrystallization rate\newline in the upper 150 m(Myr_{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
set(gca,'yscale','log');

h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171\newlineU1336,U1338','Location','southeast','FontSize',10);


box on
ax = gca;
ax.LineWidth = 1.5;
xlim([1 100])
ylim([0.0001 0.1])
set(gca,'xscale','log');
% print('ave_recry150_sedimentation_rate.jpg','-djpeg','-r600');


figure;
hold on


s80x=[1/t_803,1/t_805,1/t_806,1/t_807];
rd80x=[Rd803(1),Rd805(1),Rd806(1),Rd807(1)];

scatter(s80x,rd80x,40,'filled','o');

s126x=[1/t_1263,1/t_1264,1/t_1265,1/t_1266];
rd126x=[Rd1263(1),Rd1264(1),Rd1265(1),Rd1266(1)];

scatter(s126x,rd126x,40,'filled','s');

s98x=[1/t_982,1/t_1088,1/t_1092,1/t_1120,1/t_1169,1/t_1194];
rd98x=[Rd982(1),Rd1088(1),Rd1092(1),Rd1120(1),Rd1169(1),Rd1194(1)];

scatter(s98x,rd98x,40,'filled','d');

s28x=[1/t_516,1/t_305,1/t_289,1/t_590,1/t_575,1/t_593];
rd28x=[Rd516(1),Rd305(1),Rd289(1),Rd590(1),Rd575(1),Rd593(1)];

scatter(s28x,rd28x,40,'filled','^');

s117x=[1/t_1170,1/t_1171,1/t_1336,1/t_1338];

rd117x=[Rd1170(1),Rd1171(1),Rd1336(1),Rd1338(1)];
scatter(s117x,rd117x,40,'filled','h');

% s=[s80x,s126x,s98x,s28x,s117x];
% rd=[rd80x,rd126x,rd98x,rd28x,rd117x];
% 
% scatter(s,rd);

xlabel('Sedimentation rate (m/Myr)');
ylabel('R_d(0) (Myr^{-1})')
set(gca,'FontSize',12,'FontWeight','bold')
% set(gca,'yscale','log');
% set(gca,'xscale','log');


x=[0:1:50];
y=3.625.*10^(-5).*x.^2;
plot(x,y,'k--','linewidth',2)
h_legend = legend('803-807','1263-1266','982-1194','219-593','1170,1171,U1336,U1338','R_d(0)=3.625x10^{-5}S^2','Location','northwest');

box on
ax = gca;
ax.LineWidth = 1.5;
% xlim([1 100])
% ylim([0.0001 1])
% print('beta_sedimentation_rate.jpg','-djpeg','-r600');
