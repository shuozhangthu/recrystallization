clear all
set(0, 'DefaultAxesFontWeight', 'normal', ...
    'DefaultAxesFontSize', 14, ...
    'DefaultAxesFontAngle', 'normal', ... % Not sure the difference here
    'DefaultAxesFontWeight', 'normal', ... % Not sure the difference here
    'DefaultAxesTitleFontWeight', 'normal', ...
    'DefaultAxesTitleFontSizeMultiplier', 1) ;
set(0, 'DefaultLineLineWidth', 1);
set(0, 'DefaultAxesLineWidth', 2)

% [Leg2,Site,Depthmbsf,AgeMa] = importfile_age('age.xlsx');
load age.mat;

figure;
set(gcf, 'Position',  [100, 100, 1000, 900])

subplot(2,2,1)
title('(a)')
hold on

index=(Site==803);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-o');

i=1;
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==805);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-s');
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==806);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-h');
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==807);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-d');
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;


set(gca,'Ydir','reverse')

xlabel('Age (My)');
ylabel('Present-day depth (m)')
legend('803','805','806','807','1263','1264','1265','1266','Location','southwest','fontsize',10);
box on
ax = gca;
ax.LineWidth = 1.5;

subplot(2,2,2)
hold on
title('(b)')

index=(Site==982);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-o');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;


index=(Site==1088);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-s');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1092);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-h');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);

age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1120);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
[depth_file, a_order] = sort(depth_file);
% depth_file=depth_file(a_order);

plot(age_file,depth_file,'-d');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

% index=(Site==1169);
% age_file=AgeMa(index);
% depth_file=Depthmbsf(index);
% 
% plot(age_file,depth_file,'o');
% [depth_file,ia,ic]=unique(depth_file);
% age_file=age_file(ia);
% 
% age_mean(i)=interp1(depth_file,age_file,200);  
% i=i+1;

index=(Site==1194);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-^');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

set(gca,'Ydir','reverse')

xlabel('Age (My)');
ylabel('Present-day depth (m)')
legend('982','1088','1092','1120','1194','Location','southwest','fontsize',10);
box on
ax = gca;
ax.LineWidth = 1.5;



subplot(2,2,3)
title('(c)')
hold on

index=(Site==516);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-o');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);

age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==305);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-s');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==289);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-h');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==590);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-d');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);

age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==575);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-^');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==593);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-v');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

set(gca,'Ydir','reverse')

xlabel('Age (My)');
ylabel('Present-day depth (m)')
legend('516','305','289','590','575','593','Location','NorthEast','fontsize',10);
box on
ax = gca;
ax.LineWidth = 1.5;


subplot(2,2,4)
title('(d)')
hold on

index=(Site==1263);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-o');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1264);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-s');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1265);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-h');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1266);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-d');
 
age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1170);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
depth_file=depth_file(a_order);

plot(age_file,depth_file,'-^');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);

age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

index=(Site==1171);
age_file=AgeMa(index);
depth_file=Depthmbsf(index);
[age_file, a_order] = sort(age_file);
[depth_file, a_order] = sort(depth_file);
% depth_file=depth_file(a_order);

plot(age_file,depth_file,'-v');
[depth_file,ia,ic]=unique(depth_file);
age_file=age_file(ia);

age_mean(i)=interp1(depth_file,age_file,200);  
i=i+1;

% index=(Site==1336);
% age_file=AgeMa(index);
% depth_file=Depthmbsf(index);
% 
% scatter(age_file,depth_file,'x');
% [depth_file,ia,ic]=unique(depth_file);
% age_file=age_file(ia);
% 
% age_mean(i)=interp1(depth_file,age_file,200);  
% i=i+1;
% 
% index=(Site==1338);
% age_file=AgeMa(index);
% depth_file=Depthmbsf(index);
% 
% scatter(age_file,depth_file,'+');
% [depth_file,ia,ic]=unique(depth_file);
% age_file=age_file(ia);
% 
% age_mean(i)=interp1(depth_file,age_file,200);  
% i=i+1;

set(gca,'Ydir','reverse')

xlabel('Age (My)');
ylabel('Present-day depth (m)')
legend('1263','1264','1265','1266','1170','1171','Location','SouthWest','fontsize',10);
box on
ax = gca;
ax.LineWidth = 1.5;

print('age_depth.jpg','-djpeg','-r1200');
