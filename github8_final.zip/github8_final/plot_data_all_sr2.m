% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
set(gcf, 'Position',  [100, 100, 550, 1000])

subplot(2,1,1)
title('(a)')
hold on

xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',10,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=1170;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');


site_Number=1171;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

site_Number=1336;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'p');

site_Number=1338;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'d');


set(gca,'ColorOrderIndex',1)


site_Number=1170;
load fit_sr_1170.mat;
index=(Site1==site_Number &Depthmbsf1<400);
depth=Depthmbsf1(index);
plot(fit_sr_1170*1000,depth,'--','linewidth',2);

site_Number=1171;
load fit_sr_1171.mat;
index=(Site1==site_Number & Depthmbsf1<250);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sr_1171*1000,depth,'--','linewidth',2);

site_Number=1336;
load fit_sr_1336.mat;
index=(Site1==site_Number &Depthmbsf1<130);
depth=Depthmbsf1(index);
plot(fit_sr_1336*1000,depth,'--','linewidth',2);

site_Number=1338;
load fit_sr_1338.mat;
index=(Site1==site_Number& StrontiumSruM>0 &Depthmbsf1<200);
depth=Depthmbsf1(index);
plot(fit_sr_1338*1000,depth,'--','linewidth',2);


legend('1170','1171','1336','1338','Location','southwest');



subplot(2,1,2)
title('(b)')

hold on
xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',10,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=516;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'h');

site_Number=305;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'*');

site_Number=289;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'x');

site_Number=590;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'+');

site_Number=575;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');

site_Number=593;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

set(gca,'ColorOrderIndex',1)

site_Number=516;
load fit_sr_516.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_516*1000,depth,'--','linewidth',2);

site_Number=305;
load fit_sr_305.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_305*1000,depth,'--','linewidth',2);

site_Number=289;
load fit_sr_289.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_289*1000,depth,'--','linewidth',2);

site_Number=590;
load fit_sr_590.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_590*1000,depth,'--','linewidth',2);

site_Number=575;
load fit_sr_575.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_sr_575*1000,depth,'--','linewidth',2);

site_Number=593;
load fit_sr_593.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_593*1000,depth,'--','linewidth',2);

legend('516','305','289','590','575','593','Location','southwest');

print('all_sr2.jpg','-djpeg','-r600');

