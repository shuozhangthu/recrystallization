% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');
load('data803.mat');
load('data805.mat');
load('data806.mat');
load('data807.mat');
load('rittenhouse1.mat');
load('rittenhouse2.mat');
load('data1263.mat');
load('data1264.mat');
load('data1265.mat');
load('data1266.mat');
load('data982.mat');
load('data1088.mat');
load('data1092.mat');
load('data1120.mat');
load('data1169.mat');
load('data1194.mat');
load('data516.mat');
load('data305.mat');
load('data289.mat');
load('data590.mat');
load('data575.mat');
load('data593.mat');
load('data1170.mat');
load('data1171.mat');
load('data1336.mat');
load('data1338.mat');


figure;

hold on

xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'p');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'d');


set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_sr_803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_803*1000,depth,'--','linewidth',2);

site_Number=805;
load fit_sr_805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sr_805*1000,depth,'--','linewidth',2);

site_Number=806;
load fit_sr_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_806*1000,depth,'--','linewidth',2);

site_Number=807;
load fit_sr_807.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_807*1000,depth,'--','linewidth',2);



legend('803','805','806','807','Location','southwest');
print('Sr_80x.jpg','-djpeg','-r600');

figure;
set(gcf, 'Position',  [100, 100, 1000, 900])

subplot(2,2,1)
title('(a)')
hold on

xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'p');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'d');


set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_sr_803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_803*1000,depth,'--','linewidth',2);

site_Number=805;
load fit_sr_805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_sr_805*1000,depth,'--','linewidth',2);

site_Number=806;
load fit_sr_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_806*1000,depth,'--','linewidth',2);

site_Number=807;
load fit_sr_807.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_807*1000,depth,'--','linewidth',2);



legend('803','805','806','807','Location','southwest');

text(1000,800,'1.21%/Myr','color',[0.9290, 0.6940, 0.1250])

% 
% subplot(1,2,2)
% hold on
% title('(b)')
% 
% plot(Rd803*100,z803,'-','linewidth',2);
% plot(Rd805*100,z805,'-.','linewidth',2);
% plot(Rd806*100,z806,':','linewidth',2);
% plot(Rd807*100,z807,'--','linewidth',2);
% 
% plot(Rd1263*100,z1263,'-','linewidth',2);
% plot(Rd1264*100,z1264,'-.','linewidth',2);
% plot(Rd1265*100,z1265,':','linewidth',2);
% plot(Rd1266*100,z1266,'--','linewidth',2);
% 
% set(gca,'Ydir','reverse')
% 
% xlabel('Recrystallization rate (%/Myr)');
% ylabel('Depth (m)')
% set(gca,'FontSize',12,'FontWeight','bold')
% legend('Site 803','805','806','807','1263','1264','1265','1266','Location','SouthEast');
% box on 
% ax = gca;
% ax.LineWidth = 1.5;

% print('sr803_1266.jpg','-djpeg','-r900');


% set(gcf, 'Position',  [100, 100, 1200, 450])
% 
% subplot(1,2,1)
% title('(a)')

subplot(2,2,2)
title('(b)')
hold on
xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=982;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'h');

site_Number=1088;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'*');

site_Number=1092;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'x');

site_Number=1120;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'+');

site_Number=1169;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');

site_Number=1194;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

set(gca,'ColorOrderIndex',1)

site_Number=982;
load fit_sr_982.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_982*1000,depth,'--','linewidth',2);

site_Number=1088;
load fit_sr_1088.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1088*1000,depth,'--','linewidth',2);

site_Number=1092;
load fit_sr_1092.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1092*1000,depth,'--','linewidth',2);

site_Number=1120;
load fit_sr_1120.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1120*1000,depth,'--','linewidth',2);

site_Number=1169;
load fit_sr_1169.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1169*1000,depth,'--','linewidth',2);

site_Number=1194;
load fit_sr_1194.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_1194*1000,depth,'--','linewidth',2);

legend('982','1088','1092','1120','1169','1194','Location','southwest');

text(900,100,'1.56%/Myr','color',[0, 0.4470, 0.7410])
text(300,200,'1.26%/Myr','color',[0.9290, 0.6940, 0.1250])
text(750,200,'1.35%/Myr','color',[0.8500, 0.3250, 0.0980])

% subplot(1,2,2);
% title('(b)');
% hold on
% plot(Rd982*100,z982,'-','linewidth',2);
% plot(Rd1088*100,z1088,'-.','linewidth',2);
% plot(Rd1092*100,z1092,':','linewidth',2);
% plot(Rd1120*100,z1120,'--','linewidth',2);
% plot(Rd1169*100,z1169,'-','linewidth',2);
% plot(Rd1194*100,z1194,'-.','linewidth',2);
% 
% set(gca,'Ydir','reverse')
% 
% xlabel('Recrystallization rate (%/Myr)');
% ylabel('Depth (m)')
% set(gca,'FontSize',12,'FontWeight','bold')
% legend('Site 982','1088','1092','1120','1169','1194','Location','SouthEast');
% box on 
% ax = gca;
% ax.LineWidth = 1.5;

% print('sr982_1194.jpg','-djpeg','-r900');


subplot(2,2,3)
title('(c)')
hold on
% set(gcf, 'Position',  [100, 100, 1200, 450])
% 
% subplot(1,2,1)
% title('(a)')
xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',10,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=516;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'h');

site_Number=305;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'*');

site_Number=289;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'x');

site_Number=590;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'+');

site_Number=575;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'o');

site_Number=593;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'s');

% site_Number=984;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Sr=StrontiumSruM(index);
% scatter(Sr,depth,'d');
% 

set(gca,'ColorOrderIndex',1)

site_Number=516;
load fit_sr_516.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_516*1000,depth,'--','linewidth',2);

site_Number=305;
load fit_sr_305.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_305*1000,depth,'--','linewidth',2);

site_Number=289;
load fit_sr_289.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
% plot(fit_sr_289*1000,depth,'--','linewidth',2);

site_Number=590;
load fit_sr_590.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
% plot(fit_sr_590*1000,depth,'--','linewidth',2);

site_Number=575;
load fit_sr_575.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_sr_575*1000,depth,'--','linewidth',2);

site_Number=593;
load fit_sr_593.mat;
index=(Site1==site_Number & StrontiumSruM>0);
depth=Depthmbsf1(index);
plot(fit_sr_593*1000,depth,'--','linewidth',2);

legend('516','305','289','590','575','593','Location','southwest');

text(100,300,'0.02%/Myr','color',[0.8500, 0.3250, 0.0980])
text(950,300,'0.99%/Myr','color',[0.4940, 0.1840, 0.5560])
text(600,700,'0.71%/Myr','color',[0, 0.4470, 0.7410])

% 
% subplot(1,2,2);
% title('(b)');
% hold on
% plot(Rd516*100,z516,'-','linewidth',2);
% plot(Rd305*100,z305,'-.','linewidth',2);
% plot(Rd289*100,z289,':','linewidth',2);
% plot(Rd590*100,z590,'--','linewidth',2);
% plot(Rd575*100,z575,'-','linewidth',2);
% plot(Rd593*100,z593,'-.','linewidth',2);
% 
% set(gca,'Ydir','reverse')
% 
% xlabel('Recrystallization rate (%/Myr)');
% ylabel('Depth (m)')
% set(gca,'FontSize',12,'FontWeight','bold')
% legend('Site 516','305','289','590','575','593','Location','SouthEast');
% box on 
% ax = gca;
% ax.LineWidth = 1.5;
% 
subplot(2,2,4)
title('(d)')
hold on

xlabel('[Sr]_f (\muM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
set(gca,'FontSize',12,'FontWeight','bold')
box on
ax = gca;
ax.LineWidth = 1.5;


site_Number=1263;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'^');

site_Number=1264;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'v');

site_Number=1265;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'<');

site_Number=1266;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Sr=StrontiumSruM(index);
scatter(Sr,depth,'>');


set(gca,'ColorOrderIndex',1)


site_Number=803;

site_Number=1263;
load fit_sr_1263.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1263*1000,depth,'--','linewidth',2);


site_Number=1264;
load fit_sr_1264.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_sr_1264*1000,depth,'--','linewidth',2);

site_Number=1265;
load fit_sr_1265.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_sr_1265*1000,depth,'--','linewidth',2);

site_Number=1266;
load fit_sr_1266.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_sr_1266*1000,depth,'--','linewidth',2);

legend('1263','1264','1265','1266','Location','southwest');
ylim([0 400]);
text(250,320,'0.10%/Myr','color',[0, 0.4470, 0.7410])
text(500,320,'0.49%/Myr','color',[0.8500, 0.3250, 0.0980])

print('all_sr.jpg','-djpeg','-r900');
% 
% 
% figure;
% % set(gcf, 'Position',  [100, 100, 1200, 450])
% % 
% % subplot(1,2,1)
% % title('(a)')
% hold on
% 
% xlabel('[Sr]_f (\muM)');
% ylabel('Depth (m)')
% set(gca,'Ydir','reverse')
% set(gca,'FontSize',12,'FontWeight','bold')
% box on
% ax = gca;
% ax.LineWidth = 1.5;
% 
% site_Number=1170;
% index=(Site1==site_Number &Depthmbsf1<400);
% depth=Depthmbsf1(index);
% Sr=StrontiumSruM(index);
% scatter(Sr,depth,'o');
% 
% 
% site_Number=1171;
% index=(Site1==site_Number & StrontiumSruM>0 &Depthmbsf1<250);
% depth=Depthmbsf1(index);
% Sr=StrontiumSruM(index);
% scatter(Sr,depth,'s');
% 
% site_Number=1336;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Sr=StrontiumSruM(index);
% scatter(Sr,depth,'p');
% 
% site_Number=1338;
% index=(Site1==site_Number );
% depth=Depthmbsf1(index);
% Sr=StrontiumSruM(index);
% scatter(Sr,depth,'d');
% 
% 
% set(gca,'ColorOrderIndex',1)
% 
% 
% site_Number=1170;
% load fit_sr_1170.mat;
% index=(Site1==site_Number & StrontiumSruM>0 &Depthmbsf1<400);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% 
% plot(fit_sr_1170*1000,depth,'--','linewidth',2);
% 
% site_Number=1171;
% load fit_sr_1171.mat;
% index=(Site1==site_Number & StrontiumSruM>0 &Depthmbsf1<250);
% depth=Depthmbsf1(index);
% [depth, a_order] = sort(depth);
% plot(fit_sr_1171*1000,depth,'--','linewidth',2);
% 
% site_Number=1336;
% load fit_sr_1336.mat;
% index=(Site1==site_Number& StrontiumSruM>0 &Depthmbsf1<130);
% depth=Depthmbsf1(index);
% plot(fit_sr_1336*1000,depth,'--','linewidth',2);
% 
% site_Number=1338;
% load fit_sr_1338.mat;
% index=(Site1==site_Number& StrontiumSruM>0 &Depthmbsf1<200);
% depth=Depthmbsf1(index);
% plot(fit_sr_1338*1000,depth,'--','linewidth',2);
% 
% legend('1170','1171','U1336','U1338','Location','northeast');
% 
% text(800,150,'1.31%/Myr','color',[0, 0.4470, 0.7410])
% text(150,150,'0.50%/Myr','color',[0.9290, 0.6940, 0.1250])
% text(450,50,'0.24%/Myr','color',[0.8500, 0.3250, 0.0980])
% text(450,200,'1.26%/Myr','color',[0.4940, 0.1840, 0.5560])

% subplot(1,2,2)
% title('(b)')
% hold on
% 
% plot(Rd1170*100,z1170,'-','linewidth',2);
% plot(Rd1171*100,z1171,'-.','linewidth',2);
% plot(Rd1336*100,z1336,':','linewidth',2);
% plot(Rd1338*100,z1338,'--','linewidth',2);
% 
% set(gca,'Ydir','reverse')
% 
% xlabel('Recrystallization rate (%/Myr)');
% ylabel('Depth (m)')
% set(gca,'FontSize',12,'FontWeight','bold')
% box on 
% ax = gca;
% ax.LineWidth = 1.5;
% 
% legend('1170','1171','U1336','U1338','Location','southeast');
% print('sr1170_1338.jpg','-djpeg','-r900');

