% read data
clear
set(0, 'DefaultAxesFontWeight', 'normal', ...
    'DefaultAxesFontSize', 18, ...
    'DefaultAxesFontAngle', 'normal', ... % Not sure the difference here
    'DefaultAxesFontWeight', 'normal', ... % Not sure the difference here
    'DefaultAxesTitleFontWeight', 'normal', ...
    'DefaultAxesTitleFontSizeMultiplier', 1) ;
set(0, 'DefaultLineLineWidth', 2);
set(0, 'DefaultAxesLineWidth', 2)
set(0, 'DefaultLineMarkerSize', 6)

[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
set(gcf, 'Position',  [100, 100, 1000, 900])

subplot(2,2,1)
title('(a)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;

% site_Number=803;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% Ca=CalciumCamM(index);
% scatter(Ca,depth,'o');


site_Number=805;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=806;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

site_Number=807;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');




set(gca,'ColorOrderIndex',1)


% site_Number=803;
% load fit_ca_803.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_ca_803,depth,'--','linewidth',2);

site_Number=805;
load fit_ca_805.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_805,depth,'--','linewidth',2);

site_Number=806;
load fit_ca_806.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_806,depth,'--','linewidth',2);

site_Number=807;
load fit_ca_807.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_807,depth,'--','linewidth',2);

% xlim([10 80]);
legend('805','806','807','Location','southeast');

subplot(2,2,2)
title('(b)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=982;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');

site_Number=1088;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=1120;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

set(gca,'ColorOrderIndex',1)


site_Number=982;
load fit_ca_982.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_982,depth,'--','linewidth',2);

site_Number=1088;
load fit_ca_1088.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1088,depth,'--','linewidth',2);


site_Number=1120;
load fit_ca_1120.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1120,depth,'--','linewidth',2);

% site_Number=1169;
% load fit_ca_1169.mat;
% index=(Site1==site_Number);
% depth=Depthmbsf1(index);
% plot(fit_ca_1169,depth,'--','linewidth',2);


legend('982','1088','1120','Location','northeast');

subplot(2,2,3)
title('(c)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=516;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');

site_Number=305;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=289;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

site_Number=590;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');

set(gca,'ColorOrderIndex',1)


site_Number=516;
load fit_ca_516.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_516,depth,'--','linewidth',2);

site_Number=305;
load fit_ca_305.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_305,depth,'--','linewidth',2);

site_Number=289;
load fit_ca_289.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_289,depth,'--','linewidth',2);

site_Number=590;
load fit_ca_590.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_590,depth,'--','linewidth',2);


legend('516','305','289','590','Location','northeast');


subplot(2,2,4)
title('(d)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;



site_Number=1170;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca(1:20),depth(1:20),'^');

site_Number=1171;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca(1:16),depth(1:16),'v');

set(gca,'ColorOrderIndex',1)


site_Number=1170;
load fit_ca_1170.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1170,depth(1:20),'--','linewidth',2);

site_Number=1171;
load fit_ca_1171.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1171,depth(1:16),'--','linewidth',2);

% xlim([10 80]);
legend('1170','1171','Location','northeast');


print('all_ca.jpg','-djpeg','-r1200');

