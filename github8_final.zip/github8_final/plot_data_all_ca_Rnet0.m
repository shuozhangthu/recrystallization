% read data
clear
set(0, 'DefaultAxesFontWeight', 'normal', ...
    'DefaultAxesFontSize', 18, ...
    'DefaultAxesFontAngle', 'normal', ... % Not sure the difference here
    'DefaultAxesFontWeight', 'normal', ... % Not sure the difference here
    'DefaultAxesTitleFontWeight', 'normal', ...
    'DefaultAxesTitleFontSizeMultiplier', 1) ;
set(0, 'DefaultLineLineWidth', 2);
set(0, 'DefaultAxesLineWidth', 2)
set(0, 'DefaultLineMarkerSize', 6)

% read data
[Leg1,Site1,Topcm1,Botcm,Depthmbsf1,CalciumCamM,ChlorinityClmM,MagnesiumMgmM,pHpHna,SodiumNamM,StrontiumSruM,SulfateSO4mM,SilicaH4SiO4uM,AlkalinityALKmM,SalinitySALna] = importfile_water('water.xlsx');

figure;
set(gcf, 'Position',  [100, 100, 1000, 380])

subplot(1,2,1)
title('(a)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;

site_Number=803;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=1092;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

site_Number=1194;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'^');

site_Number=575;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);

scatter(Ca,depth,'^');

site_Number=593;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'v');

set(gca,'ColorOrderIndex',1)


site_Number=803;
load fit_ca_803.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_803,depth,'--','linewidth',2);


site_Number=1092;
load fit_ca_1092.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1092,depth,'--','linewidth',2);

site_Number=1194;
load fit_ca_1194.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_1194,depth,'--','linewidth',2);

site_Number=575;
load fit_ca_575.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_ca_575,depth,'--','linewidth',2);

site_Number=593;
load fit_ca_593.mat;
index=(Site1==site_Number & CalciumCamM>0);
depth=Depthmbsf1(index);
plot(fit_ca_593,depth,'--','linewidth',2);

legend('803','1092','1194','575','593','Location','northeast');

subplot(1,2,2)
title('(b)')

hold on
xlabel('[Ca]_f (mM)');
ylabel('Depth (m)')
set(gca,'Ydir','reverse')
box on
ax = gca;
ax.LineWidth = 1.5;


site_Number=1263;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'o');

site_Number=1264;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'s');

site_Number=1265;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'h');

site_Number=1266;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
Ca=CalciumCamM(index);
scatter(Ca,depth,'d');


set(gca,'ColorOrderIndex',1)


site_Number=1263;
load fit_ca_1263.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);
plot(fit_ca_1263,depth,'--','linewidth',2);

site_Number=1264;
load fit_ca_1264.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_ca_1264,depth,'--','linewidth',2);

site_Number=1265;
load fit_ca_1265.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
[depth, a_order] = sort(depth);

plot(fit_ca_1265,depth,'--','linewidth',2);

site_Number=1266;
load fit_ca_1266.mat;
index=(Site1==site_Number);
depth=Depthmbsf1(index);
plot(fit_ca_1266,depth,'--','linewidth',2);

% xlim([10 80]);
legend('1263','1264','1265','1266','Location','northeast');


print('all_ca2.jpg','-djpeg','-r1200');

